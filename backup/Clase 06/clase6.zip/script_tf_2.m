function s = script_tf_2

% Ejercicios 7 y 8 de la gu?a de ejercicios de transformada de Fourier, que
% involucran la antitransformada.

x7 = ejercicio7();
[x8,n] = ejercicio8();

s = struct('Ejercicio7',x7,'Ejercicio8',x8,'Comentario_ej8',n);

end

function x = ejercicio7
    syms t w;

    X = 2*sign(w)*heaviside(-w+2)*heaviside(w+2);
    %figure(1)
    %fplot(X); grid on; 

    % calculo de x(t):
    x = 1/(2*sym(pi))*int(X*exp(j*w*t),w,-inf,inf);

    %figure(2)
    %fplot(abs(x))

end

function [x,n] = ejercicio8

    syms t w
    X = 2*pi*dirac(w) + pi*dirac(w - 4*pi) + pi*dirac(w + 4*pi);
    x = ifourier(X,t);
    x = simplify(x,'Steps',50);
    n = sprintf(['Al calcular a mano la antitransformada, se pueden usar las propiedades \n' ...
    'vistas en clase: la transformada generalizada, los corrimientos en tiempo y' ...
    'en frecuencia \njunto con la identidad de Euler de los cosenos. ' ...
    'Rapidamente en MATLAB podemos \ncorroborar el resultado. ']);
end