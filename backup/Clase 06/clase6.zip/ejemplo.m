function y = ejemplo
% Este script permite calcular la transformada de Fourier de una funcion 
% definida con symfun. A su vez, permite desplegar las graficas de x en 
% funcion del tiempo y de X en funcion de la frecuencia. 

y.transformada = @transformada;
y.ploteo = @ploteo;

end

function [X] = transformada(x)

X = fourier(x);
X = simplifyFraction(X);

end

function ploteo(X,wmin,wmax)

fplot(abs(X),[wmin wmax])
title('Transformada')
xlabel('Frecuencia [w]')
ylabel('|X(w)|')
grid on;
end


